package com.at.rest.carserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
