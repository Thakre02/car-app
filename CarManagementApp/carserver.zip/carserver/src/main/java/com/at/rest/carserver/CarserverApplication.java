package com.at.rest.carserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarserverApplication.class, args);
	}

}
